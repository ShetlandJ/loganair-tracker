Loganair fares to and from Sumburgh: data pack
Data to: 2026-11-08T13:51:39 UTC
Prepared by: James Stewart

What this is: Automated checks of the fare calendar on loganair.co.uk (the date picker shown when you search for a flight).
What a fare means: The lowest one-way fare per person shown for that day, across all flights that day. Not a per-flight price. Not checked against the final checkout total.
Full fare: The standard fare anyone can buy.
ADS fare: The fare shown when the Air Discount Scheme option is selected. Tracked from 19 Oct 2026. The ADS calendar has gaps (dates with a full fare but no ADS fare shown); these are a data collection issue, not ADS fares being unavailable.
Routes and start dates: Edinburgh and Aberdeen (both directions): full fares from 10 Oct 2026. Glasgow (both directions) and all ADS fares: from 19 Oct 2026.
How often: 135 checks between 2026-10-10 and 2026-11-08; typically every 5.2 hours. Fares that changed and changed back between checks are missed.
Change logs: A row is written only when a date's fare or status changes, so the change log sheets are compact. The fare in force at any time is the most recent row before it.
Status values: flight-has-price: a fare was shown. flight-no-price: no fare shown (sold out, not yet on sale, or no flight). flight-not-available: date not available to book.

Sheets
1 Sunday v midweek: Current fares for flights 14+ days away. Each row is one week: the Sunday fare against the average of Tue, Wed and Thu of the same week.
2 Same flight: Flights that had reached 2 days out by the data date. The fare shown at the last check 21, 14, 7 and 2 days before the same flight. Blank = we weren't tracking that date yet.
3 Fares today: Every route and date on sale, full and ADS, as of the data date.
Change log full / ADS: Every recorded change, unprocessed.
Checks: Every collection run: time, routes fetched, dates seen, changes recorded.

Limits: Four weeks of data. No seasonal comparison is possible yet. Short-notice figures cover Oct and Nov 2026 flights only. Loganair has not been asked to comment.
Source code and raw data: github.com/shetlandj/loganair-tracker
